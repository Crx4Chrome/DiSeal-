# DiSeal
Official DiSeal (diseal) roblox extension github. To use it you must have RoSeal installed. What does it do? its a chrome extension that allows you to get free roblox limiteds easier

# SETTING UP
  # --Mobile--
To set it up on mobile, first of find a browser that supports extensions(like kiwi browser), download file as zip and enable developers mode in extensions. Click on unpack extension from zip and select the zip file with extension

  # --Pc--
To set it up on PC, first go to your browser go to chrome://extensions/ and enable developers mode. Unpack your zip file and save it to folder. When you done that go to chrome://extensions/ once again, and click "Load unpacked", and select folder where you unpacked your extension. Now it shouldve added to your extensions menu, and you can use it.
